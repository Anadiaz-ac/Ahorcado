
package juego_ahorcado_anamariadiaz;


public class Nodo {
    
    private String d;
    private Nodo Liga;
    
    public Nodo(String d)
    {
        this.d=d;
        Liga=null;
        
    }

    public String getPalabra() {
        return d;
    }

    public void setPalabra(String d) {
        this.d = d;
    }

    public Nodo getLiga() {
        return Liga;
    }

    public void setLiga(Nodo Liga) {
        this.Liga = Liga;
    }
    
    
    
    
}
