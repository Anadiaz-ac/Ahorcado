/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package juego_ahorcado_anamariadiaz;
   
import javax.swing.JOptionPane;
import static juego_ahorcado_anamariadiaz.Lista_Nodo.contfallidos;

public class Ahorcado extends javax.swing.JFrame {
    
     Lista_Nodo lis=new Lista_Nodo();
     
     public static String letra="";
     public static String palabra="";
     

 
    public Ahorcado() 
    {
        
        initComponents();
        deshabitaImagen();
        
        lis.Insertarinicio("banano");
        lis.Insertarinicio("murcielago");
        lis.Insertarinicio("guanabana");
        lis.Insertarinicio("apartamento");
        lis.Insertarinicio("mandarina");
        lis.Insertarinicio("arbol");
        lis.Insertarinicio("computador");
        lis.Insertarinicio("ventilador");
        lis.Insertarinicio("calavera");
        lis.Insertarinicio("pastel");
        
    }
    
    public void deshabitaImagen() 
    {
        
        m1.setVisible(false);
        m2.setVisible(false);
        m3.setVisible(false);
        m4.setVisible(false);
        m5.setVisible(false);
        m6.setVisible(false);
       
   }
    
    public void deshabilitaletras()
    {
        this.btnA.setEnabled(false);
        this.btnB.setEnabled(false);
        this.btnC.setEnabled(false);
        this.btnD.setEnabled(false);
        this.btnE.setEnabled(false);
        this.btnF.setEnabled(false);
        this.btnG.setEnabled(false);
        this.btnH.setEnabled(false);
        this.btnI.setEnabled(false);
        this.btnJ.setEnabled(false);
        this.btnK.setEnabled(false);
        this.btnL.setEnabled(false);
        this.btnM.setEnabled(false);
        this.btnN.setEnabled(false);
        this.btnÑ.setEnabled(false);
        this.btnO.setEnabled(false);
        this.btnP.setEnabled(false);
        this.btnQ.setEnabled(false);
        this.btnR.setEnabled(false);
        this.btnS.setEnabled(false);
        this.btnT.setEnabled(false);
        this.btnU.setEnabled(false);
        this.btnV.setEnabled(false);
        this.btnW.setEnabled(false);
        this.btnX.setEnabled(false);
        this.btnY.setEnabled(false);
        this.btnZ.setEnabled(false);
    }
    
    public void habilitaletras()
    {
        this.btnA.setEnabled(true);
        this.btnB.setEnabled(true);
        this.btnC.setEnabled(true);
        this.btnD.setEnabled(true);
        this.btnE.setEnabled(true);
        this.btnF.setEnabled(true);
        this.btnG.setEnabled(true);
        this.btnH.setEnabled(true);
        this.btnI.setEnabled(true);
        this.btnJ.setEnabled(true);
        this.btnK.setEnabled(true);
        this.btnL.setEnabled(true);
        this.btnM.setEnabled(true);
        this.btnN.setEnabled(true);
        this.btnÑ.setEnabled(true);
        this.btnO.setEnabled(true);
        this.btnP.setEnabled(true);
        this.btnQ.setEnabled(true);
        this.btnR.setEnabled(true);
        this.btnS.setEnabled(true);
        this.btnT.setEnabled(true);
        this.btnU.setEnabled(true);
        this.btnV.setEnabled(true);
        this.btnW.setEnabled(true);
        this.btnX.setEnabled(true);
        this.btnY.setEnabled(true);
        this.btnZ.setEnabled(true); 
    }
    
    public void mostrarimagen()
    {
       
        switch(contfallidos)
        {
            case 1:
                m1.setVisible(true);
                break;
            case 2:
                m1.setVisible(false);
                m2.setVisible(true);
                 break;
            case 3:
                m1.setVisible(false);
                m2.setVisible(false);
                m3.setVisible(true);
                  break;
            case 4:
                m1.setVisible(false);
                m2.setVisible(false);
                m3.setVisible(false);
                m4.setVisible(true);
                 break;
            case 5:
                m1.setVisible(false);
                m2.setVisible(false);
                m3.setVisible(false);
                m4.setVisible(false);
                m5.setVisible(true);
                 break;
            case 6:
                m1.setVisible(false);
                m2.setVisible(false);
                m3.setVisible(false);
                m4.setVisible(false);
                m5.setVisible(false);
                m6.setVisible(true);
                JOptionPane.showMessageDialog(null, "Demasiados intentos, juego finalizado!\nLa palabra era: "+palabra);
                deshabilitaletras();
                break;
            
       } 
    }
    
    

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Titulo = new javax.swing.JLabel();
        Intentos = new javax.swing.JLabel();
        txtIntentos = new javax.swing.JTextField();
        btnSalir = new javax.swing.JButton();
        txtRayas = new javax.swing.JLabel();
        txtletras = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        btnZ = new javax.swing.JButton();
        btnA = new javax.swing.JButton();
        btnC = new javax.swing.JButton();
        btnD = new javax.swing.JButton();
        btnE = new javax.swing.JButton();
        btnF = new javax.swing.JButton();
        btnL = new javax.swing.JButton();
        btnK = new javax.swing.JButton();
        btnJ = new javax.swing.JButton();
        btnI = new javax.swing.JButton();
        btnH = new javax.swing.JButton();
        btnG = new javax.swing.JButton();
        btnM = new javax.swing.JButton();
        btnN = new javax.swing.JButton();
        btnÑ = new javax.swing.JButton();
        btnO = new javax.swing.JButton();
        btnP = new javax.swing.JButton();
        btnQ = new javax.swing.JButton();
        btnW = new javax.swing.JButton();
        btnV = new javax.swing.JButton();
        btnU = new javax.swing.JButton();
        btnT = new javax.swing.JButton();
        btnS = new javax.swing.JButton();
        btnR = new javax.swing.JButton();
        btnX = new javax.swing.JButton();
        btnY = new javax.swing.JButton();
        m1 = new javax.swing.JLabel();
        m2 = new javax.swing.JLabel();
        m3 = new javax.swing.JLabel();
        m4 = new javax.swing.JLabel();
        m5 = new javax.swing.JLabel();
        m6 = new javax.swing.JLabel();
        btnB = new javax.swing.JButton();
        btnComenzar = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(204, 204, 255));
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        getContentPane().setLayout(null);

        Titulo.setFont(new java.awt.Font("Bodoni MT", 0, 24)); // NOI18N
        Titulo.setForeground(new java.awt.Color(0, 51, 102));
        Titulo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Titulo.setText("AHORCADO");
        getContentPane().add(Titulo);
        Titulo.setBounds(200, 20, 220, 29);

        Intentos.setFont(new java.awt.Font("Gadugi", 0, 14)); // NOI18N
        Intentos.setForeground(new java.awt.Color(51, 51, 51));
        Intentos.setText("Intentos fallidos:");
        getContentPane().add(Intentos);
        Intentos.setBounds(40, 80, 100, 20);

        txtIntentos.setEditable(false);
        txtIntentos.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtIntentos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtIntentosActionPerformed(evt);
            }
        });
        getContentPane().add(txtIntentos);
        txtIntentos.setBounds(150, 80, 30, 20);

        btnSalir.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        btnSalir.setText("Salir");
        btnSalir.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 0, 0)));
        btnSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalirActionPerformed(evt);
            }
        });
        getContentPane().add(btnSalir);
        btnSalir.setBounds(410, 380, 113, 35);

        txtRayas.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        txtRayas.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        getContentPane().add(txtRayas);
        txtRayas.setBounds(310, 130, 200, 30);
        getContentPane().add(txtletras);
        txtletras.setBounds(310, 130, 200, 20);

        jLabel4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        getContentPane().add(jLabel4);
        jLabel4.setBounds(290, 120, 240, 50);

        btnZ.setText("Z");
        btnZ.setEnabled(false);
        btnZ.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnZActionPerformed(evt);
            }
        });
        getContentPane().add(btnZ);
        btnZ.setBounds(420, 320, 50, 30);

        btnA.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        btnA.setText("A");
        btnA.setEnabled(false);
        btnA.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAActionPerformed(evt);
            }
        });
        getContentPane().add(btnA);
        btnA.setBounds(250, 200, 50, 30);

        btnC.setText("C");
        btnC.setEnabled(false);
        btnC.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCActionPerformed(evt);
            }
        });
        getContentPane().add(btnC);
        btnC.setBounds(350, 200, 50, 30);

        btnD.setText("D");
        btnD.setEnabled(false);
        btnD.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDActionPerformed(evt);
            }
        });
        getContentPane().add(btnD);
        btnD.setBounds(400, 200, 50, 30);

        btnE.setText("E");
        btnE.setEnabled(false);
        btnE.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEActionPerformed(evt);
            }
        });
        getContentPane().add(btnE);
        btnE.setBounds(450, 200, 50, 30);

        btnF.setText("F");
        btnF.setEnabled(false);
        btnF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFActionPerformed(evt);
            }
        });
        getContentPane().add(btnF);
        btnF.setBounds(500, 200, 50, 30);

        btnL.setText("L");
        btnL.setEnabled(false);
        btnL.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLActionPerformed(evt);
            }
        });
        getContentPane().add(btnL);
        btnL.setBounds(500, 230, 50, 30);

        btnK.setText("K");
        btnK.setEnabled(false);
        btnK.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnKActionPerformed(evt);
            }
        });
        getContentPane().add(btnK);
        btnK.setBounds(450, 230, 50, 30);

        btnJ.setText("J");
        btnJ.setEnabled(false);
        btnJ.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnJActionPerformed(evt);
            }
        });
        getContentPane().add(btnJ);
        btnJ.setBounds(400, 230, 50, 30);

        btnI.setText("I");
        btnI.setEnabled(false);
        btnI.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnIActionPerformed(evt);
            }
        });
        getContentPane().add(btnI);
        btnI.setBounds(350, 230, 50, 30);

        btnH.setText("H");
        btnH.setEnabled(false);
        btnH.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnHActionPerformed(evt);
            }
        });
        getContentPane().add(btnH);
        btnH.setBounds(300, 230, 50, 30);

        btnG.setText("G");
        btnG.setEnabled(false);
        btnG.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGActionPerformed(evt);
            }
        });
        getContentPane().add(btnG);
        btnG.setBounds(250, 230, 50, 30);

        btnM.setText("M");
        btnM.setEnabled(false);
        btnM.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMActionPerformed(evt);
            }
        });
        getContentPane().add(btnM);
        btnM.setBounds(250, 260, 50, 30);

        btnN.setText("N");
        btnN.setEnabled(false);
        btnN.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNActionPerformed(evt);
            }
        });
        getContentPane().add(btnN);
        btnN.setBounds(300, 260, 50, 30);

        btnÑ.setText("Ñ");
        btnÑ.setEnabled(false);
        btnÑ.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnÑActionPerformed(evt);
            }
        });
        getContentPane().add(btnÑ);
        btnÑ.setBounds(350, 260, 50, 30);

        btnO.setText("O");
        btnO.setEnabled(false);
        btnO.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnOActionPerformed(evt);
            }
        });
        getContentPane().add(btnO);
        btnO.setBounds(400, 260, 50, 30);

        btnP.setText("P");
        btnP.setEnabled(false);
        btnP.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPActionPerformed(evt);
            }
        });
        getContentPane().add(btnP);
        btnP.setBounds(450, 260, 50, 30);

        btnQ.setText("Q");
        btnQ.setEnabled(false);
        btnQ.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnQActionPerformed(evt);
            }
        });
        getContentPane().add(btnQ);
        btnQ.setBounds(500, 260, 50, 30);

        btnW.setText("W");
        btnW.setEnabled(false);
        btnW.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnWActionPerformed(evt);
            }
        });
        getContentPane().add(btnW);
        btnW.setBounds(500, 290, 50, 30);

        btnV.setText("V");
        btnV.setEnabled(false);
        btnV.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVActionPerformed(evt);
            }
        });
        getContentPane().add(btnV);
        btnV.setBounds(450, 290, 50, 30);

        btnU.setText("U");
        btnU.setEnabled(false);
        btnU.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUActionPerformed(evt);
            }
        });
        getContentPane().add(btnU);
        btnU.setBounds(400, 290, 50, 30);

        btnT.setText("T");
        btnT.setEnabled(false);
        btnT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTActionPerformed(evt);
            }
        });
        getContentPane().add(btnT);
        btnT.setBounds(350, 290, 50, 30);

        btnS.setText("S");
        btnS.setEnabled(false);
        btnS.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSActionPerformed(evt);
            }
        });
        getContentPane().add(btnS);
        btnS.setBounds(300, 290, 50, 30);

        btnR.setText("R");
        btnR.setEnabled(false);
        btnR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRActionPerformed(evt);
            }
        });
        getContentPane().add(btnR);
        btnR.setBounds(250, 290, 50, 30);

        btnX.setText("X");
        btnX.setEnabled(false);
        btnX.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnXActionPerformed(evt);
            }
        });
        getContentPane().add(btnX);
        btnX.setBounds(320, 320, 50, 30);

        btnY.setText("Y");
        btnY.setEnabled(false);
        btnY.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnYActionPerformed(evt);
            }
        });
        getContentPane().add(btnY);
        btnY.setBounds(370, 320, 50, 30);

        m1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/m1.png"))); // NOI18N
        m1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        getContentPane().add(m1);
        m1.setBounds(40, 130, 180, 200);

        m2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/m2.png"))); // NOI18N
        m2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        getContentPane().add(m2);
        m2.setBounds(40, 130, 180, 200);

        m3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/m3.png"))); // NOI18N
        m3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        getContentPane().add(m3);
        m3.setBounds(40, 130, 180, 200);

        m4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/m4.png"))); // NOI18N
        m4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        getContentPane().add(m4);
        m4.setBounds(40, 130, 180, 200);

        m5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/m5.png"))); // NOI18N
        m5.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        getContentPane().add(m5);
        m5.setBounds(40, 130, 180, 200);

        m6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/m6.png"))); // NOI18N
        m6.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        getContentPane().add(m6);
        m6.setBounds(40, 130, 180, 200);

        btnB.setText("B");
        btnB.setEnabled(false);
        btnB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBActionPerformed(evt);
            }
        });
        getContentPane().add(btnB);
        btnB.setBounds(300, 200, 50, 30);

        btnComenzar.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        btnComenzar.setText("Comenzar");
        btnComenzar.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(51, 204, 0)));
        btnComenzar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnComenzarActionPerformed(evt);
            }
        });
        getContentPane().add(btnComenzar);
        btnComenzar.setBounds(290, 380, 113, 35);

        jLabel1.setFont(new java.awt.Font("Gadugi", 0, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(102, 102, 102));
        jLabel1.setText("Adivina la palabra");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(350, 90, 120, 20);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalirActionPerformed
      
     System.exit(WIDTH);
     
    }//GEN-LAST:event_btnSalirActionPerformed

    private void btnJActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnJActionPerformed
        letra="j";
        this.btnJ.setEnabled(false);
        lis.letras.buscar(letra);
        this.txtRayas.setText(lis.rayas.cadena());
        this.txtIntentos.setText(String.valueOf(lis.contfallidos));
        mostrarimagen();
    }//GEN-LAST:event_btnJActionPerformed



    private void btnAActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAActionPerformed
         letra="a";
        this.btnA.setEnabled(false);
        lis.letras.buscar(letra);
        this.txtRayas.setText(lis.rayas.cadena());
        this.txtIntentos.setText(String.valueOf(lis.contfallidos));
        mostrarimagen();
    }//GEN-LAST:event_btnAActionPerformed

    private void btnCActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCActionPerformed
         letra="c";
        this.btnC.setEnabled(false);
        lis.letras.buscar(letra);
        this.txtRayas.setText(lis.rayas.cadena());
        this.txtIntentos.setText(String.valueOf(lis.contfallidos));
        mostrarimagen();
    }//GEN-LAST:event_btnCActionPerformed

    private void btnDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDActionPerformed
        letra="d";
        this.btnD.setEnabled(false);
        lis.letras.buscar(letra);
        this.txtRayas.setText(lis.rayas.cadena());
        this.txtIntentos.setText(String.valueOf(lis.contfallidos));
        mostrarimagen();
    }//GEN-LAST:event_btnDActionPerformed

    private void btnEActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEActionPerformed
        letra="e";
        this.btnE.setEnabled(false);
        lis.letras.buscar(letra);
        this.txtRayas.setText(lis.rayas.cadena());
        this.txtIntentos.setText(String.valueOf(lis.contfallidos));
        mostrarimagen();
    }//GEN-LAST:event_btnEActionPerformed

    private void btnFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFActionPerformed
         letra="f";
        this.btnF.setEnabled(false);
        lis.letras.buscar(letra);
        this.txtRayas.setText(lis.rayas.cadena());
        this.txtIntentos.setText(String.valueOf(lis.contfallidos));
        mostrarimagen();
    }//GEN-LAST:event_btnFActionPerformed

    private void btnGActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGActionPerformed
        letra="g";
        this.btnG.setEnabled(false);
        lis.letras.buscar(letra);
        this.txtRayas.setText(lis.rayas.cadena());
        this.txtIntentos.setText(String.valueOf(lis.contfallidos));
        mostrarimagen();
    }//GEN-LAST:event_btnGActionPerformed

    private void btnHActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnHActionPerformed
        letra="h";
        this.btnH.setEnabled(false);
        lis.letras.buscar(letra);
        this.txtRayas.setText(lis.rayas.cadena());
        this.txtIntentos.setText(String.valueOf(lis.contfallidos));
        mostrarimagen();
        
    }//GEN-LAST:event_btnHActionPerformed

    private void btnIActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnIActionPerformed
    
         letra="i";
        this.btnI.setEnabled(false);
        lis.letras.buscar(letra);
        this.txtRayas.setText(lis.rayas.cadena());
        this.txtIntentos.setText(String.valueOf(lis.contfallidos));
        mostrarimagen();
    }//GEN-LAST:event_btnIActionPerformed

    private void txtIntentosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtIntentosActionPerformed
          
    }//GEN-LAST:event_txtIntentosActionPerformed

    private void btnKActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnKActionPerformed
         letra="k";
        this.btnK.setEnabled(false);
        lis.letras.buscar(letra);
        this.txtRayas.setText(lis.rayas.cadena());
        this.txtIntentos.setText(String.valueOf(lis.contfallidos));
        mostrarimagen();
    }//GEN-LAST:event_btnKActionPerformed

    private void btnLActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLActionPerformed
         letra="l";
        this.btnL.setEnabled(false);
        lis.letras.buscar(letra);
        this.txtRayas.setText(lis.rayas.cadena());
        this.txtIntentos.setText(String.valueOf(lis.contfallidos));
        mostrarimagen();
    }//GEN-LAST:event_btnLActionPerformed

    private void btnMActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMActionPerformed
         letra="m";
        this.btnM.setEnabled(false);
        lis.letras.buscar(letra);
        this.txtRayas.setText(lis.rayas.cadena());
        this.txtIntentos.setText(String.valueOf(lis.contfallidos));
        mostrarimagen();
    }//GEN-LAST:event_btnMActionPerformed

    private void btnNActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNActionPerformed
         letra="n";
        this.btnN.setEnabled(false);
        lis.letras.buscar(letra);
        this.txtRayas.setText(lis.rayas.cadena());
        this.txtIntentos.setText(String.valueOf(lis.contfallidos));
        mostrarimagen();
    }//GEN-LAST:event_btnNActionPerformed

    private void btnÑActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnÑActionPerformed
         letra="ñ";
        this.btnÑ.setEnabled(false);
        lis.letras.buscar(letra);
        this.txtRayas.setText(lis.rayas.cadena());
        this.txtIntentos.setText(String.valueOf(lis.contfallidos));
        mostrarimagen();
    }//GEN-LAST:event_btnÑActionPerformed

    private void btnOActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnOActionPerformed
        letra="o";
        this.btnO.setEnabled(false);
        lis.letras.buscar(letra);
        this.txtRayas.setText(lis.rayas.cadena());
        this.txtIntentos.setText(String.valueOf(lis.contfallidos));
        mostrarimagen();
    }//GEN-LAST:event_btnOActionPerformed

    private void btnPActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPActionPerformed
        letra="p";
        this.btnP.setEnabled(false);
        lis.letras.buscar(letra);
        this.txtRayas.setText(lis.rayas.cadena());
        this.txtIntentos.setText(String.valueOf(lis.contfallidos));
        mostrarimagen();
    }//GEN-LAST:event_btnPActionPerformed

    private void btnQActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnQActionPerformed
         letra="q";
        this.btnQ.setEnabled(false);
        lis.letras.buscar(letra);
        this.txtRayas.setText(lis.rayas.cadena());
        this.txtIntentos.setText(String.valueOf(lis.contfallidos));
        mostrarimagen();
    }//GEN-LAST:event_btnQActionPerformed

    private void btnRActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRActionPerformed
         letra="r";
        this.btnR.setEnabled(false);
        lis.letras.buscar(letra);
        this.txtRayas.setText(lis.rayas.cadena());
        this.txtIntentos.setText(String.valueOf(lis.contfallidos));
        mostrarimagen();
    }//GEN-LAST:event_btnRActionPerformed

    private void btnSActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSActionPerformed
        letra="s";
        this.btnS.setEnabled(false);
        lis.letras.buscar(letra);
        this.txtRayas.setText(lis.rayas.cadena());
        this.txtIntentos.setText(String.valueOf(lis.contfallidos));
        mostrarimagen();
    }//GEN-LAST:event_btnSActionPerformed

    private void btnTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTActionPerformed
         letra="t";
        this.btnT.setEnabled(false);
        lis.letras.buscar(letra);
        this.txtRayas.setText(lis.rayas.cadena());
        this.txtIntentos.setText(String.valueOf(lis.contfallidos));
        mostrarimagen();
    }//GEN-LAST:event_btnTActionPerformed

    private void btnUActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUActionPerformed
         letra="u";
        this.btnU.setEnabled(false);
        lis.letras.buscar(letra);
        this.txtRayas.setText(lis.rayas.cadena());
        this.txtIntentos.setText(String.valueOf(lis.contfallidos));
        mostrarimagen();
    }//GEN-LAST:event_btnUActionPerformed

    private void btnVActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVActionPerformed
         letra="v";
        this.btnV.setEnabled(false);
        lis.letras.buscar(letra);
        this.txtRayas.setText(lis.rayas.cadena());
        this.txtIntentos.setText(String.valueOf(lis.contfallidos));
        mostrarimagen();
    }//GEN-LAST:event_btnVActionPerformed

    private void btnWActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnWActionPerformed
         letra="w";
        this.btnW.setEnabled(false);
        lis.letras.buscar(letra);
        this.txtRayas.setText(lis.rayas.cadena());
        this.txtIntentos.setText(String.valueOf(lis.contfallidos));
        mostrarimagen();
    }//GEN-LAST:event_btnWActionPerformed

    private void btnXActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnXActionPerformed
        letra="x";
        this.btnX.setEnabled(false);
        lis.letras.buscar(letra);
        this.txtRayas.setText(lis.rayas.cadena());
        this.txtIntentos.setText(String.valueOf(lis.contfallidos));
        mostrarimagen();
    }//GEN-LAST:event_btnXActionPerformed

    private void btnYActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnYActionPerformed
         letra="y";
        this.btnY.setEnabled(false);
        lis.letras.buscar(letra);
        this.txtRayas.setText(lis.rayas.cadena());
        this.txtIntentos.setText(String.valueOf(lis.contfallidos));
        mostrarimagen();
    }//GEN-LAST:event_btnYActionPerformed

    private void btnZActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnZActionPerformed
        letra="z";
        this.btnZ.setEnabled(false);
        lis.letras.buscar(letra);
        this.txtRayas.setText(lis.rayas.cadena());
        this.txtIntentos.setText(String.valueOf(lis.contfallidos));
        mostrarimagen();
    }//GEN-LAST:event_btnZActionPerformed

    private void btnBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBActionPerformed
        letra="b";
        this.btnB.setEnabled(false);
        lis.letras.buscar(letra);
        this.txtRayas.setText(lis.rayas.cadena());
        this.txtIntentos.setText(String.valueOf(lis.contfallidos));
        mostrarimagen();
    }//GEN-LAST:event_btnBActionPerformed

    
    private void btnComenzarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnComenzarActionPerformed
        traerpalabra();
        lis.jugar(palabra);
        this.txtRayas.setText(lis.rayas.cadena());
        habilitaletras();
        this.btnComenzar.setEnabled(false);

    }//GEN-LAST:event_btnComenzarActionPerformed

    public String traerpalabra()
    {
       palabra=lis.Obtenerpalabra();
       return palabra;
    }
    public static void main(String args[]) {
       
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Ahorcado.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Ahorcado.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Ahorcado.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Ahorcado.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Ahorcado().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Intentos;
    private javax.swing.JLabel Titulo;
    private javax.swing.JButton btnA;
    private javax.swing.JButton btnB;
    private javax.swing.JButton btnC;
    private javax.swing.JButton btnComenzar;
    private javax.swing.JButton btnD;
    private javax.swing.JButton btnE;
    private javax.swing.JButton btnF;
    private javax.swing.JButton btnG;
    private javax.swing.JButton btnH;
    private javax.swing.JButton btnI;
    private javax.swing.JButton btnJ;
    private javax.swing.JButton btnK;
    private javax.swing.JButton btnL;
    private javax.swing.JButton btnM;
    private javax.swing.JButton btnN;
    private javax.swing.JButton btnO;
    private javax.swing.JButton btnP;
    private javax.swing.JButton btnQ;
    private javax.swing.JButton btnR;
    private javax.swing.JButton btnS;
    private javax.swing.JButton btnSalir;
    private javax.swing.JButton btnT;
    private javax.swing.JButton btnU;
    private javax.swing.JButton btnV;
    private javax.swing.JButton btnW;
    private javax.swing.JButton btnX;
    private javax.swing.JButton btnY;
    private javax.swing.JButton btnZ;
    private javax.swing.JButton btnÑ;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel m1;
    private javax.swing.JLabel m2;
    private javax.swing.JLabel m3;
    private javax.swing.JLabel m4;
    private javax.swing.JLabel m5;
    private javax.swing.JLabel m6;
    private javax.swing.JTextField txtIntentos;
    private javax.swing.JLabel txtRayas;
    private javax.swing.JLabel txtletras;
    // End of variables declaration//GEN-END:variables

   
}
