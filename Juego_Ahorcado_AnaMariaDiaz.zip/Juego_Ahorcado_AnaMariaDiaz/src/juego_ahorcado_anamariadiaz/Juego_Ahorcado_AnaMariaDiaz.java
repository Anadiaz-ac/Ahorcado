package juego_ahorcado_anamariadiaz;


public class Juego_Ahorcado_AnaMariaDiaz {

   
    public static void main(String[] args) {
        
        new Ahorcado().setVisible(true);
        
    }
    
}
