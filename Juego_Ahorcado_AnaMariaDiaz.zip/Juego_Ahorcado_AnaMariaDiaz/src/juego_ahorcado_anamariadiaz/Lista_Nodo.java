package juego_ahorcado_anamariadiaz;

import javax.swing.*;

public class Lista_Nodo {
    
    Nodo cabeza;
    String palabra="";
    int cont;
   
    public static Lista_Nodo letras=new Lista_Nodo();
    public static Lista_Nodo rayas=new Lista_Nodo();
 
    public static int cd=0;
    public static int contfallidos=0;
    
    public Lista_Nodo()
    {
         cabeza=null;
    }
    
    public void Insertarinicio(String d){
        
        Nodo q;
        
        q=new Nodo(d);
        if(cabeza==null)
        {
            cabeza=q;
        }
        else{
            q.setLiga(cabeza);
            cabeza=q;
        }
        
    }
    
    public void InsertarFinal(String d)
    {
        Nodo p,q;
        p=cabeza;
        q=new Nodo(d);
        
        if(cabeza==null)
        {
            cabeza=q;
        }
        else{
           while(p.getLiga()!=null)
        {
           p=p.getLiga();
        }
         
         p.setLiga(q); 
        }
    }
    
    
    public String Obtenerpalabra()
    {
        
        Nodo p=cabeza;
        int rdn =(int)(Math.random()*10)+1;
        
        for (int i = 0; i < 10; i++)
        {
            p=p.getLiga(); 
            
            if(rdn==i)
            {
                palabra=p.getPalabra();
            }
        }
           
        return palabra;
    }
    
    public void jugar(String palabra)
    {
        if(palabra=="")
        {
            palabra=Obtenerpalabra();
        }
        for (int i = 0; i < palabra.length(); i++) 
        {
            letras.InsertarFinal(String.valueOf(palabra.charAt(i)));
            rayas.InsertarFinal("_");
        }
    }
    
    public void Ingresarletra(String letra, int pos)
    {
       Nodo p;
       p=cabeza;
       cont=1;
       
        while(p!=null && cont<pos)
        {
            cont++;
            p=p.getLiga();
        }
        p.setPalabra(letra);
    }
    
    public void buscar(String letra)
    {
       Nodo p;
       p=cabeza;
       int pos=1;
       
       while(p!=null)
       {
           if(p.getPalabra().equals(letra))
           {
               cd++;
              rayas.Ingresarletra(letra,pos);
           }
           
           p=p.getLiga();
           pos++;
       }
       
       if(cd==0)
       {
           JOptionPane.showMessageDialog(null,"Intenta con otra letra");
           contfallidos++;
       }
       cd=0;
    }
    
       public String cadena(){  

         Nodo p;
         p=cabeza;
         String cad=" ";

         while (p!=null)
         {
             cad=cad+p.getPalabra()+" ";
              p=p.getLiga();
         }

         return cad;

       }
       
       
       public void limpiar()
       {
            Lista_Nodo letras=null;
            Lista_Nodo rayas=null;
            letras=new Lista_Nodo();
            rayas=new Lista_Nodo();
       }
    
}